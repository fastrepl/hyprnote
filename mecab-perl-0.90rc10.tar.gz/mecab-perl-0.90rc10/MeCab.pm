# This file was created automatically by SWIG 1.3.28.
# Don't modify this file, modify the SWIG interface instead.
package MeCab;
require Exporter;
require DynaLoader;
@ISA = qw(Exporter DynaLoader);
package MeCabc;
bootstrap MeCab;
package MeCab;
@EXPORT = qw( );

# ---------- BASE METHODS -------------

package MeCab;

sub TIEHASH {
    my ($classname,$obj) = @_;
    return bless $obj, $classname;
}

sub CLEAR { }

sub FIRSTKEY { }

sub NEXTKEY { }

sub FETCH {
    my ($self,$field) = @_;
    my $member_func = "swig_${field}_get";
    $self->$member_func();
}

sub STORE {
    my ($self,$field,$newval) = @_;
    my $member_func = "swig_${field}_set";
    $self->$member_func($newval);
}

sub this {
    my $ptr = shift;
    return tied(%$ptr);
}


# ------- FUNCTION WRAPPERS --------

package MeCab;


############# Class : MeCab::Path ##############

package MeCab::Path;
use vars qw(@ISA %OWNER %ITERATORS %BLESSEDMEMBERS);
@ISA = qw( MeCab );
%OWNER = ();
%ITERATORS = ();
*swig_rnode_get = *MeCabc::Path_rnode_get;
*swig_rnode_set = *MeCabc::Path_rnode_set;
*swig_rnext_get = *MeCabc::Path_rnext_get;
*swig_rnext_set = *MeCabc::Path_rnext_set;
*swig_lnode_get = *MeCabc::Path_lnode_get;
*swig_lnode_set = *MeCabc::Path_lnode_set;
*swig_lnext_get = *MeCabc::Path_lnext_get;
*swig_lnext_set = *MeCabc::Path_lnext_set;
*swig_cost_get = *MeCabc::Path_cost_get;
*swig_cost_set = *MeCabc::Path_cost_set;
*swig_prob_get = *MeCabc::Path_prob_get;
*swig_prob_set = *MeCabc::Path_prob_set;
sub DISOWN {
    my $self = shift;
    my $ptr = tied(%$self);
    delete $OWNER{$ptr};
}

sub ACQUIRE {
    my $self = shift;
    my $ptr = tied(%$self);
    $OWNER{$ptr} = 1;
}


############# Class : MeCab::Node ##############

package MeCab::Node;
use vars qw(@ISA %OWNER %ITERATORS %BLESSEDMEMBERS);
@ISA = qw( MeCab );
%OWNER = ();
%ITERATORS = ();
*swig_prev_get = *MeCabc::Node_prev_get;
*swig_prev_set = *MeCabc::Node_prev_set;
*swig_next_get = *MeCabc::Node_next_get;
*swig_next_set = *MeCabc::Node_next_set;
*swig_enext_get = *MeCabc::Node_enext_get;
*swig_enext_set = *MeCabc::Node_enext_set;
*swig_bnext_get = *MeCabc::Node_bnext_get;
*swig_bnext_set = *MeCabc::Node_bnext_set;
*swig_rpath_get = *MeCabc::Node_rpath_get;
*swig_rpath_set = *MeCabc::Node_rpath_set;
*swig_lpath_get = *MeCabc::Node_lpath_get;
*swig_lpath_set = *MeCabc::Node_lpath_set;
*swig_feature_get = *MeCabc::Node_feature_get;
*swig_feature_set = *MeCabc::Node_feature_set;
*swig_id_get = *MeCabc::Node_id_get;
*swig_id_set = *MeCabc::Node_id_set;
*swig_length_get = *MeCabc::Node_length_get;
*swig_length_set = *MeCabc::Node_length_set;
*swig_rlength_get = *MeCabc::Node_rlength_get;
*swig_rlength_set = *MeCabc::Node_rlength_set;
*swig_rcAttr_get = *MeCabc::Node_rcAttr_get;
*swig_rcAttr_set = *MeCabc::Node_rcAttr_set;
*swig_lcAttr_get = *MeCabc::Node_lcAttr_get;
*swig_lcAttr_set = *MeCabc::Node_lcAttr_set;
*swig_posid_get = *MeCabc::Node_posid_get;
*swig_posid_set = *MeCabc::Node_posid_set;
*swig_char_type_get = *MeCabc::Node_char_type_get;
*swig_char_type_set = *MeCabc::Node_char_type_set;
*swig_stat_get = *MeCabc::Node_stat_get;
*swig_stat_set = *MeCabc::Node_stat_set;
*swig_isbest_get = *MeCabc::Node_isbest_get;
*swig_isbest_set = *MeCabc::Node_isbest_set;
*swig_alpha_get = *MeCabc::Node_alpha_get;
*swig_alpha_set = *MeCabc::Node_alpha_set;
*swig_beta_get = *MeCabc::Node_beta_get;
*swig_beta_set = *MeCabc::Node_beta_set;
*swig_prob_get = *MeCabc::Node_prob_get;
*swig_prob_set = *MeCabc::Node_prob_set;
*swig_wcost_get = *MeCabc::Node_wcost_get;
*swig_wcost_set = *MeCabc::Node_wcost_set;
*swig_cost_get = *MeCabc::Node_cost_get;
*swig_cost_set = *MeCabc::Node_cost_set;
*swig_surface_get = *MeCabc::Node_surface_get;
*swig_surface_set = *MeCabc::Node_surface_set;
sub DISOWN {
    my $self = shift;
    my $ptr = tied(%$self);
    delete $OWNER{$ptr};
}

sub ACQUIRE {
    my $self = shift;
    my $ptr = tied(%$self);
    $OWNER{$ptr} = 1;
}


############# Class : MeCab::Tagger ##############

package MeCab::Tagger;
use vars qw(@ISA %OWNER %ITERATORS %BLESSEDMEMBERS);
@ISA = qw( MeCab );
%OWNER = ();
%ITERATORS = ();
*parse = *MeCabc::Tagger_parse;
*parseToNode = *MeCabc::Tagger_parseToNode;
*parseNBest = *MeCabc::Tagger_parseNBest;
*parseNBestInit = *MeCabc::Tagger_parseNBestInit;
*nextNode = *MeCabc::Tagger_nextNode;
*next = *MeCabc::Tagger_next;
*formatNode = *MeCabc::Tagger_formatNode;
*what = *MeCabc::Tagger_what;
sub DESTROY {
    return unless $_[0]->isa('HASH');
    my $self = tied(%{$_[0]});
    return unless defined $self;
    delete $ITERATORS{$self};
    if (exists $OWNER{$self}) {
        MeCabc::delete_Tagger($self);
        delete $OWNER{$self};
    }
}

sub new {
    my $pkg = shift;
    my $self = MeCabc::new_Tagger(@_);
    bless $self, $pkg if defined($self);
}

*parseToString = *MeCabc::Tagger_parseToString;
sub DISOWN {
    my $self = shift;
    my $ptr = tied(%$self);
    delete $OWNER{$ptr};
}

sub ACQUIRE {
    my $self = shift;
    my $ptr = tied(%$self);
    $OWNER{$ptr} = 1;
}


# ------- VARIABLE STUBS --------

package MeCab;

*MECAB_NOR_NODE = *MeCabc::MECAB_NOR_NODE;
*MECAB_UNK_NODE = *MeCabc::MECAB_UNK_NODE;
*MECAB_BOS_NODE = *MeCabc::MECAB_BOS_NODE;
*MECAB_EOS_NODE = *MeCabc::MECAB_EOS_NODE;
*VERSION = *MeCabc::VERSION;
1;
