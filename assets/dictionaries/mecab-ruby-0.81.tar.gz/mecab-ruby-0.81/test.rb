#!/usr/bin/ruby

require 'MeCab'
sentence = "��Ϻ�Ϥ����ܤ���Ϻ�򸫤��������Ϥ�����"

arg = [$0] + ARGV

begin
     c = MeCab::Tagger.new(arg)

     puts c.parse(sentence)

     # c.lock();
     n = c.parseToNode(sentence)
     
     puts n.toString();

     while n.hasNode() != 0 do
       print n.getSurface(),  "\t", n.getFeature(), "\t", n.getTotalCost(), "\n"
       n = n.next()
     end
     print "EOS\n";

     # c.unlock()
     
rescue
      print "RuntimeError: ", $!, "\n";
end
  

